#include <WiFi.h>
#include <ESPmDNS.h>
#include <WebServer.h>
#include <Adafruit_NeoPixel.h>
#include <ESP32Servo.h>
#include "Portal.h" 

// --- CONFIGURACIÓN WIFI ---
const char* ssid = "Robotica";
const char* password = "robotica-22";

WebServer server(80);

// --- ALMACÉN DEL JUEGO BOOM ---
String pregunta = "Esperando pregunta...";
String respuestas[5] = {"Esperando R1...", "Esperando R2...", "Esperando R3...", "Esperando R4...", "Esperando R5..."};
int correctaID = 0; 

// --- CONFIGURACIÓN COMPONENTES ---
int currentNeoPin = 26;
int currentNeoNum = 16;
Adafruit_NeoPixel strip(currentNeoNum, currentNeoPin, NEO_GRB + NEO_KHZ800);
Servo myServo;

// Función para enviar datos con todos los permisos necesarios para navegadores modernos
void sendData(String data) {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  server.send(200, "text/plain", data);
}

void sendOK() {
  sendData("OK");
}

void setup() {
  Serial.begin(115200);
  
  strip.begin();
  strip.clear();
  strip.show();

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi Conectado");

  // --- CONFIGURACIÓN NOMBRE DINÁMICO (esp32-mac.local) ---
  String mac = WiFi.macAddress();
  mac.replace(":", "");
  mac.toLowerCase();
  String dnsName = "esp32-" + mac;
  
  if (MDNS.begin(dnsName.c_str())) {
    Serial.print("Servidor iniciado en: http://");
    Serial.print(dnsName);
    Serial.println(".local");
  }

  // ==========================================
  //      RUTAS DEL PORTAL (Móvil)
  // ==========================================
  
  server.on("/", HTTP_GET, []() {
    server.send(200, "text/html", html_page);
  });

  server.on("/configurar", HTTP_GET, []() {
    if(server.hasArg("p"))  pregunta = server.arg("p");
    if(server.hasArg("r1")) respuestas[0] = server.arg("r1");
    if(server.hasArg("r2")) respuestas[1] = server.arg("r2");
    if(server.hasArg("r3")) respuestas[2] = server.arg("r3");
    if(server.hasArg("r4")) respuestas[3] = server.arg("r4");
    if(server.hasArg("r5")) respuestas[4] = server.arg("r5");
    if(server.hasArg("c"))  correctaID = server.arg("c").toInt();
    
    Serial.println("¡Nueva partida recibida!");
    sendOK();
  });

  // ==========================================
  //      RUTAS PARA SCRATCH (Lectura)
  // ==========================================
  
  server.on("/get_pregunta", HTTP_GET, []() { sendData(pregunta); });
  server.on("/get_r1", HTTP_GET, []() { sendData(respuestas[0]); });
  server.on("/get_r2", HTTP_GET, []() { sendData(respuestas[1]); });
  server.on("/get_r3", HTTP_GET, []() { sendData(respuestas[2]); });
  server.on("/get_r4", HTTP_GET, []() { sendData(respuestas[3]); });
  server.on("/get_r5", HTTP_GET, []() { sendData(respuestas[4]); });
  server.on("/get_correcta", HTTP_GET, []() { sendData(String(correctaID)); });

  // ==========================================
  //      ACTUADORES Y SENSORES
  // ==========================================
  
  server.on("/pin", HTTP_GET, []() {
    if (server.hasArg("numero") && server.hasArg("estado")) {
      int pin = server.arg("numero").toInt();
      String estado = server.arg("estado");
      pinMode(pin, OUTPUT);
      digitalWrite(pin, (estado == "on") ? HIGH : LOW);
    }
    sendOK();
  });

  server.on("/dread", HTTP_GET, []() {
    int pin = server.arg("numero").toInt();
    pinMode(pin, INPUT_PULLUP);
    sendData(String(digitalRead(pin)));
  });

  server.on("/aread", HTTP_GET, []() {
    int pin = server.arg("numero").toInt();
    sendData(String(analogRead(pin)));
  });

  server.on("/neofill", HTTP_GET, []() {
    int r = server.arg("r").toInt();
    int g = server.arg("g").toInt();
    int b = server.arg("b").toInt();
    strip.fill(strip.Color(r, g, b));
    strip.show();
    sendOK();
  });

  server.on("/neoclear", HTTP_GET, []() {
    strip.clear();
    strip.show();
    sendOK();
  });

  server.on("/servo", HTTP_GET, []() {
    int pin = server.arg("pin").toInt();
    int angulo = server.arg("angulo").toInt();
    myServo.attach(pin); 
    myServo.write(angulo);
    sendOK();
  });

  server.on("/distancia", HTTP_GET, []() {
    int trig = server.arg("trig").toInt();
    int echo = server.arg("echo").toInt();
    pinMode(trig, OUTPUT);
    pinMode(echo, INPUT);
    digitalWrite(trig, LOW); delayMicroseconds(2);
    digitalWrite(trig, HIGH); delayMicroseconds(10);
    digitalWrite(trig, LOW);
    long duracion = pulseIn(echo, HIGH, 30000);
    sendData(String(int(duracion * 0.034 / 2)));
  });

  server.begin();
}

void loop() {
  server.handleClient();
  delay(2); // Delay pequeño para estabilidad del stack WiFi
}