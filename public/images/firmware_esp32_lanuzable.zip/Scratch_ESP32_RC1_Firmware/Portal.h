// Archivo: Portal.h - Panel de Producción ¡BOOM!
const char* html_page = R"=====(
<!DOCTYPE html>
<html>
<head>
  <title>BOOM! Production Suite</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: 'Segoe UI', sans-serif; background: #0d1117; color: #c9d1d9; padding: 15px; }
    .box { background: #161b22; border: 1px solid #30363d; padding: 20px; border-radius: 12px; max-width: 500px; margin: auto; box-shadow: 0 8px 32px rgba(0,0,0,0.5); }
    h2 { color: #58a6ff; text-align: center; margin-top: 0; }
    .input-group { margin-bottom: 15px; }
    label { display: block; font-size: 0.9em; margin-bottom: 5px; color: #8b949e; }
    input[type=text] { width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #30363d; background: #0d1117; color: white; box-sizing: border-box; }
    .res-row { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; background: #21262d; padding: 8px; border-radius: 6px; }
    input[type=radio] { transform: scale(1.5); cursor: pointer; }
    button { width: 100%; background: #238636; color: white; padding: 15px; border: none; border-radius: 6px; font-weight: bold; font-size: 1em; cursor: pointer; margin-top: 10px; transition: 0.2s; }
    button:active { background: #2ea043; transform: scale(0.98); }
    .hint { font-size: 0.8em; color: #f0883e; text-align: center; margin-top: 10px; }
  </style>
</head>
<body>
  <div class="box">
    <h2>Control de Partida</h2>
    
    <div class="input-group">
      <label>Pregunta del Juego:</label>
      <input type="text" id="p" placeholder="Ej: ¿Cual es el planeta rojo?">
    </div>
    
    <label>Respuestas (Marca la que NO explota):</label>
    <div class="res-row"> <input type="radio" name="c" value="1" checked> <input type="text" id="r1" placeholder="Respuesta 1 (Roja)"> </div>
    <div class="res-row"> <input type="radio" name="c" value="2"> <input type="text" id="r2" placeholder="Respuesta 2 (Azul)"> </div>
    <div class="res-row"> <input type="radio" name="c" value="3"> <input type="text" id="r3" placeholder="Respuesta 3 (Verde)"> </div>
    <div class="res-row"> <input type="radio" name="c" value="4"> <input type="text" id="r4" placeholder="Respuesta 4 (Amarilla)"> </div>
    <div class="res-row"> <input type="radio" name="c" value="5"> <input type="text" id="r5" placeholder="Respuesta 5 (Blanca)"> </div>
    
    <button onclick="enviar()">CARGAR DATOS EN LA BOMBA</button>
    <div class="hint">Una vez cargados, pulsa la tecla 'C' en Scratch para actualizar.</div>
  </div>

  <script>
    function enviar() {
      let p = encodeURIComponent(document.getElementById('p').value);
      let r1 = encodeURIComponent(document.getElementById('r1').value);
      let r2 = encodeURIComponent(document.getElementById('r2').value);
      let r3 = encodeURIComponent(document.getElementById('r3').value);
      let r4 = encodeURIComponent(document.getElementById('r4').value);
      let r5 = encodeURIComponent(document.getElementById('r5').value);
      let c = document.querySelector('input[name="c"]:checked').value;
      
      let url = `/configurar?p=${p}&r1=${r1}&r2=${r2}&r3=${r3}&r4=${r4}&r5=${r5}&c=${c}`;
      
      fetch(url)
        .then(response => {
          if(response.ok) alert("✅ ¡Datos enviados correctamente!");
          else alert("❌ Error al enviar");
        })
        .catch(err => alert("❌ No se pudo conectar con la ESP32"));
    }
  </script>
</body>
</html>
)=====";